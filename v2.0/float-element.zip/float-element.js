/*
    元素悬停插件
*/
/*************************************************************************************************/

(
    function( $ )
    {
        /*
            在这个函数体内使用this关键字，直接就是指向$()选择器中选中的元素了（已经包装成jq对象）
        */
        $.fn.floatElement = function(option)
        {
            // 预设默认的选项参数 //
            var defaults =
                {
                    respondTo:     "parent",
                    relativeTo:    "parent",
                    listenType:    "once",
                    top:           "initial",
                    bottom:        "initial",
                    left:          "initial",
                    right:         "initial",
                    destroy:        false,
                };

            // 实际应用的选项参数 //
            var applys = $.extend( defaults, option );

            // 变量参数 //
            var respond_to = null;
            var relative_to = null;

            var top_away = null;
            var bottom_away = null;
            var left_away = null;
            var right_away = null;

            var top_off = null;
            var bottom_off = null;
            var left_off = null;
            var right_off = null;

            // 1.创建or销毁监听 /////////////////////////////////////////////////////////////////////
            if(applys.destroy == true)                                                    //销毁监听
            {

            }
            else                                                                          //创建监听
            {
                // 设置悬停元素css定位为relative //
                $(this).css("position", "relative");

                // 1.5设置响应容器 //////////////////////////////////////////////////////////////////
                if(applys.respondTo == "parent")                                      //响应 = 父容器
                {   respond_to = this.parent();   }
                else                                                              //响应 = 指定的容器
                {   respond_to = $(applys.respondTo);   }

                // 2.选择监听类型 ///////////////////////////////////////////////////////////////////
                if(applys.listenType == "once")                                           //监听一次
                {
                    // 3.依据相对容器采用悬停模式 ////////////////////////////////////////////////////
                    if(applys.relativeTo == "self")                                       //偏移模式
                    {
                        relative_to = this;                                            //相对 = 自己

                        // 赋值偏移约束 //
                        assignOff();

                        // 依据既有设置创建滚动监听 //
                        $(respond_to).scroll
                        (
                            //scrollEvent1Off(this, respond_to, relative_to, top_off, bottom_off, left_off, right_off)
                            function(){console.log("haha");}
                        );


                    }
                    else                                                                  //边距模式
                    {
                        if(applys.relativeTo == "parent")                            //相对 = 父容器
                        {   relative_to = this.parent();   }
                        else                                                      //相对 = 指定的容器
                        {   relative_to = $(applys.relativeTo);   }

                        // 赋值边距约束 //
                        assignAway();

                        // 依据既有设置创建滚动监听 //
                        scrollEvent1Away(this, respond_to, relative_to, top_away, bottom_away, left_away, right_away);


                    }
                }
                else                                                                      //监听每次
                {
                    if(applys.relativeTo == "self")                                       //偏移模式
                    {

                    }
                    else                                                                  //边距模式
                    {

                    }
                }


            }

            /*
                定义在下面的函数在执行时会被提升上去
            */
            // 赋值边距和偏移模式的位移量约束，利用了闭包 /////////////////////////////////////////////
            function assignOff()                                                      //赋值偏移约束
            {
                if(applys.top == "initial")      {   top_off = 0;            }
                else if(applys.top == "free")    {   top_off = "free";       }
                else                             {   top_off = applys.top;   }

                if(applys.bottom == "initial")      {   bottom_off = 0;               }
                else if(applys.bottom == "free")    {   bottom_off = "free";          }
                else                                {   bottom_off = applys.bottom;   }

                if(applys.left == "initial")      {   left_off = 0;             }
                else if(applys.left == "free")    {   left_off = "free";        }
                else                              {   left_off = applys.left;   }

                if(applys.right == "initial")      {   right_off = 0;              }
                else if(applys.right == "free")    {   right_off = "free";         }
                else                               {   right_off = applys.right;   }

                console.log(respond_to);
                console.log(relative_to);
                console.log(top_off);
                console.log(bottom_off);
                console.log(left_off);
                console.log(right_off);
            }
            function assignAway()                                                     //赋值边距约束
            {
                if(applys.top == "initial")      {   top_away = 0;            }
                else if(applys.top == "free")    {   top_away = "free";       }
                else                             {   top_away = applys.top;   }

                if(applys.bottom == "initial")      {   bottom_away = 0;               }
                else if(applys.bottom == "free")    {   bottom_away = "free";          }
                else                                {   bottom_away = applys.bottom;   }

                if(applys.left == "initial")      {   left_away = 0;             }
                else if(applys.left == "free")    {   left_away = "free";        }
                else                              {   left_away = applys.left;   }

                if(applys.right == "initial")      {   right_away = 0;              }
                else if(applys.right == "free")    {   right_away = "free";         }
                else                               {   right_away = applys.right;   }

                console.log(respond_to);
                console.log(relative_to);
                console.log(top_away);
                console.log(bottom_away);
                console.log(left_away);
                console.log(right_away);
            }
            // 定义滚动条监听响应事件 ////////////////////////////////////////////////////////////////
            function scrollEvent1Off                                          //监听一次，偏移模式
                (float_element, respond_to, relative_to, top_off, bottom_off, left_off, right_off)
                {
                    console.log(this);

                    console.log(float_element);
                    console.log(respond_to);
                    console.log(relative_to);
                    console.log(top_off);
                    console.log(bottom_off);
                    console.log(left_off);
                    console.log(right_off);

                    console.log( $(respond_to).scrollTop() );
                    console.log( $(respond_to).scrollLeft() );
                }
            function scrollEvent1Away                                         //监听一次，边距模式
                (float_element, respond_to, relative_to, top_away, bottom_away, left_away, right_away)
                {

                }
            function scrollEventNOff                                          //监听每次，偏移模式
                (float_element, respond_to, relative_to, top_off, bottom_off, left_off, right_off)
                {

                }
            function scrollEventNAway                                         //监听每次，边距模式
                (float_element, respond_to, relative_to, top_away, bottom_away, left_away, right_away)
                {

                }




        };
    }
)( jQuery );







































/**/
